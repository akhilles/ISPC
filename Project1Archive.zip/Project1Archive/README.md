# Password Cracker

### To build (on Linux):

1. Add `ispc-v1.9.1-linux` folder to path

2. Need clang to compile

   `sudo apt-get install clang`

3. `make`

4. To crack a password, for example, "pass"
  `./md5 "pass"`

