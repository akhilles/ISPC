# pragma once

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string.h>
#include <stdint.h>

void crack_ispc(uint8_t initial_msg[4], int len, bool serial, int tasks);