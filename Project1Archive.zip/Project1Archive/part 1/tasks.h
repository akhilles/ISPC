extern "C" {
 void ISPCLaunch(void **handlePtr, void *f, void *data, int count0, int count1, int count2);
 void ISPCSync(void *handle);
 }
